import tkinter as tk


def submit():
    print("Submit button clicked")


# Create the main window
root = tk.Tk()
root.title("LARS Comparison Settings")

# Create left and right frames
rootl = tk.Frame(root)
rootl.pack(side=tk.LEFT, padx=10, pady=10)

rootr = tk.Frame(root)
rootr.pack(side=tk.LEFT, padx=10, pady=10)

# Add some example widgets to the left frame
label_left = tk.Label(rootl, text="Left Frame")
label_left.pack(padx=10, pady=10)

entry_left = tk.Entry(rootl)
entry_left.pack(padx=10, pady=5)

# Add some example widgets to the right frame
label_right = tk.Label(rootr, text="Right Frame")
label_right.pack(padx=10, pady=10)

entry_right = tk.Entry(rootr)
entry_right.pack(padx=10, pady=5)

# Create a frame for the submit button that takes full width
button_frame = tk.Frame(root)
button_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=20)  # Fill horizontally

# Create the Submit button
submit_button = tk.Button(button_frame, text="Submit", command=submit)
submit_button.pack(side=tk.TOP, pady=10)  # Center the button in the frame

# Start the main loop
root.mainloop()
